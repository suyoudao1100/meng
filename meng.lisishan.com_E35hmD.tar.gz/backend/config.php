<?php
define('BASE_URL', 'https://api.xunyihn.com/artemis/api/user/profile/invite/users');
define('DEFAULT_SIZE', 20);
define('MAX_RETRIES', 3);

// 默认接口参数
define('DEFAULT_PARAMS', [
    'view_mode' => 'full_screen',
    'sid' => '20WbRsS6IQo2QWz6Nvj5brzAGi0TI1eYUS9fGbdMmH6H3di0oysv0gi3i3',
    'cv' => 'DREAMBABY2.4.60_Android',
    'cc' => 'TG000112239',
    'ownid' => '55124537',
    '_t' => 0
]);
